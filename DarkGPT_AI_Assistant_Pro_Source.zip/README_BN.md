# DarkGPT AI Assistant Pro (Android Java)

এটি একটি starter project: Android Java app + Node.js backend + OpenAI Responses API.

## ফিচার
- বাংলা/English AI chat
- Android speech recognition (voice input)
- Android Text-to-Speech (voice output)
- Code mode
- Ethical cybersecurity tutor mode (authorized/defensive learning only)
- Dark UI

## যা লাগবে
- Android Studio (JDK 17 সহ)
- Node.js 20 বা নতুন
- OpenAI API key এবং API billing/usage access

## ধাপ ১ — Backend চালু করুন
1. `backend` ফোল্ডার খুলুন।
2. Terminal-এ চালান: `npm install`
3. `.env.example` ফাইল কপি করে `.env` নাম দিন।
4. `.env`-এ নিজের API key বসান। API key কাউকে দেবেন না।
5. চালান: `npm start`
6. ব্রাউজারে `http://localhost:3000` খুলে `{"status":"DarkGPT backend running"}` দেখুন।

## ধাপ ২ — Android Studio
1. Android Studio → Open → এই `DarkGPTPro` project folder নির্বাচন করুন।
2. Gradle sync শেষ হতে দিন।
3. Emulator ব্যবহার করলে `MainActivity.java`-এর API_URL `http://10.0.2.2:3000/chat` রাখুন।
4. বাস্তব Android ফোনে app ও computer একই Wi-Fi-তে থাকলে `10.0.2.2`-এর বদলে computer-এর LAN IP দিন, যেমন `http://192.168.1.5:3000/chat`।
5. ফোনে Android 6+ হলে প্রথম voice ব্যবহারে Microphone permission দিন।
6. Run চাপুন।

## ধাপ ৩ — APK বানান
Android Studio → Build → Build Bundle(s) / APK(s) → Build APK(s).
APK সাধারণত `app/build/outputs/apk/debug/app-debug.apk`-এ পাওয়া যাবে।

## গুরুত্বপূর্ণ নিরাপত্তা
- API key কখনো Android code, APK, GitHub বা chat-এ রাখবেন না। এটি শুধু backend-এর `.env`-এ রাখুন।
- এই sample-এ local development সহজ করতে HTTP enabled। Public release-এর আগে HTTPS ব্যবহার করুন, CORS সীমিত করুন, authentication, rate limiting, abuse protection এবং billing limits যোগ করুন।
- Android app-এর API_URL-এ public server URL দিন; `10.0.2.2` শুধু Android emulator-এর জন্য।
- Voice recognition ফোনের speech service ব্যবহার করে; ভাষার সাপোর্ট ডিভাইস/সার্ভিসভেদে বদলাতে পারে।
- OpenAI API usage ChatGPT subscription থেকে আলাদা billing হতে পারে।
- এই starter production-ready authentication বা user-data storage দেয় না। ব্যক্তিগত/সংবেদনশীল তথ্য পাঠাবেন না।

## সমস্যা হলে
- `Connection refused`: backend চলছে কি না এবং IP/port সঠিক কি না দেখুন।
- `401`: API key ভুল/অকার্যকর।
- `429`: rate limit বা billing/usage limit।
- `model not found`: `.env`-এর `OPENAI_MODEL`-এ আপনার API project-এ উপলব্ধ model দিন।
