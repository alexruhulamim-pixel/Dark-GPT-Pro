import express from "express";
import cors from "cors";
import dotenv from "dotenv";
import OpenAI from "openai";

dotenv.config();
if (!process.env.OPENAI_API_KEY) {
  console.error("Missing OPENAI_API_KEY. Copy .env.example to .env and add your key.");
  process.exit(1);
}
const app = express();
app.use(cors()); // For production, restrict this to your own app/domain.
app.use(express.json({ limit: "30kb" }));

const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
const MODEL = process.env.OPENAI_MODEL || "gpt-6.2-astra";

app.get("/", (_req, res) => res.json({ status: "DarkGPT backend running" }));

app.post("/chat", async (req, res) => {
  try {
    const message = String(req.body?.message || "").trim();
    if (!message) return res.status(400).json({ error: "Message is required" });
    if (message.length > 12000) return res.status(413).json({ error: "Message too long" });

    const response = await client.responses.create({
      model: MODEL,
      instructions:
        "You are DarkGPT, a helpful bilingual Bangla and English assistant. " +
        "Answer in the language the user uses. Be clear and practical. " +
        "For coding, explain code and mention security best practices. " +
        "For cybersecurity, teach only legal, authorized labs, defensive security, " +
        "and responsible disclosure. Never help compromise real accounts, devices, " +
        "networks, steal credentials, deploy malware, or evade detection.",
      input: message
    });
    res.json({ reply: response.output_text || "No text response was returned." });
  } catch (err) {
    console.error("AI request failed:", err?.message || err);
    res.status(500).json({ error: "AI request failed. Check server logs and API account." });
  }
});

const port = Number(process.env.PORT || 3000);
app.listen(port, "0.0.0.0", () => console.log(`DarkGPT backend listening on ${port}`));
