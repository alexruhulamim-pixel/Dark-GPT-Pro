package com.darkgpt.pro;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.RecognitionListener;
import android.speech.tts.TextToSpeech;
import android.view.Gravity;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.content.Context;
import android.widget.*;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import org.json.JSONObject;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.concurrent.*;
import android.Manifest;
import android.content.pm.PackageManager;

public class MainActivity extends Activity {
    private final int BG = Color.rgb(16,18,27);
    private final int PANEL = Color.rgb(35,38,57);
    private final int PURPLE = Color.rgb(167,139,250);
    private LinearLayout messages;
    private EditText input;
    private TextView status;
    private String mode = "chat";
    private ExecutorService executor = Executors.newSingleThreadExecutor();
    private TextToSpeech tts;
    private SpeechRecognizer speech;
    // Emulator: 10.0.2.2. For a real phone, replace with your computer's LAN IP.
    private static final String API_URL = "http://10.0.2.2:3000/chat";

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        tts = new TextToSpeech(this, result -> {});
        buildUI();
        addMessage("DarkGPT", "স্বাগতম! আমি আপনার AI assistant. কীভাবে সাহায্য করতে পারি?");
    }

    private GradientDrawable shape(int color, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color); d.setCornerRadius(radius);
        return d;
    }

    private TextView label(String text, int size, int color) {
        TextView t = new TextView(this);
        t.setText(text); t.setTextSize(size); t.setTextColor(color);
        return t;
    }

    private void buildUI() {
        LinearLayout base = new LinearLayout(this);
        base.setOrientation(LinearLayout.VERTICAL);
        base.setPadding(18, 18, 18, 12);
        base.setBackgroundColor(BG);

        LinearLayout header = new LinearLayout(this);
        header.setGravity(Gravity.CENTER_VERTICAL);
        TextView logo = label("◈  DarkGPT", 24, Color.WHITE);
        logo.setTypeface(null, Typeface.BOLD);
        header.addView(logo, new LinearLayout.LayoutParams(0, -2, 1));
        status = label("PRO • ONLINE UI", 11, PURPLE);
        header.addView(status);
        base.addView(header);

        TextView subtitle = label("বাংলা • English  |  Your personal AI", 13, 0xFFAAAFC4);
        LinearLayout.LayoutParams subP = new LinearLayout.LayoutParams(-1, -2);
        subP.setMargins(0, 6, 0, 14);
        base.addView(subtitle, subP);

        HorizontalScrollView hsv = new HorizontalScrollView(this);
        hsv.setHorizontalScrollBarEnabled(false);
        LinearLayout modes = new LinearLayout(this);
        String[][] items = {{"AI Chat","chat"},{"Code","code"},{"Ethical Hacking","security"}};
        for (String[] item : items) {
            Button btn = new Button(this);
            btn.setText(item[0]); btn.setTextColor(Color.WHITE);
            btn.setTextSize(12); btn.setAllCaps(false);
            btn.setBackground(shape(PANEL, 22));
            LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(-2, 46);
            bp.setMargins(0, 0, 8, 0);
            modes.addView(btn, bp);
            btn.setOnClickListener(v -> {
                mode = item[1];
                status.setText("MODE • " + item[0].toUpperCase(Locale.US));
                addMessage("System", item[0] + " mode selected.");
            });
        }
        hsv.addView(modes);
        base.addView(hsv);

        ScrollView scroll = new ScrollView(this);
        messages = new LinearLayout(this);
        messages.setOrientation(LinearLayout.VERTICAL);
        messages.setPadding(0, 14, 0, 14);
        scroll.addView(messages);
        base.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));

        LinearLayout composer = new LinearLayout(this);
        composer.setGravity(Gravity.CENTER_VERTICAL);
        input = new EditText(this);
        input.setSingleLine(false);
        input.setMinLines(1); input.setMaxLines(4);
        input.setTextColor(Color.WHITE); input.setHintTextColor(0xFF9297AA);
        input.setHint("আপনার প্রশ্ন লিখুন...");
        input.setPadding(14, 10, 14, 10);
        input.setBackground(shape(PANEL, 24));
        composer.addView(input, new LinearLayout.LayoutParams(0, -2, 1));

        Button mic = new Button(this);
        mic.setText("🎙"); mic.setTextSize(16); mic.setAllCaps(false);
        mic.setTextColor(Color.WHITE); mic.setBackground(shape(PANEL, 22));
        composer.addView(mic, new LinearLayout.LayoutParams(54, 52));
        mic.setOnClickListener(v -> startVoice());

        Button send = new Button(this);
        send.setText("➤"); send.setTextSize(20); send.setAllCaps(false);
        send.setTextColor(Color.WHITE); send.setBackground(shape(PURPLE, 22));
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(54, 52);
        sp.setMargins(7,0,0,0); composer.addView(send, sp);
        send.setOnClickListener(v -> sendMessage());
        base.addView(composer);
        setContentView(base);
    }

    private void addMessage(String who, String text) {
        TextView bubble = label(who + "\n" + text, 15, Color.WHITE);
        bubble.setPadding(14, 11, 14, 11);
        bubble.setBackground(shape(who.equals("You") ? 0xFF493B70 : PANEL, 18));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(
            who.equals("You") ? (int)(getResources().getDisplayMetrics().widthPixels * .82) : -1, -2);
        p.setMargins(who.equals("You") ? 35 : 0, 5, who.equals("You") ? 0 : 35, 8);
        p.gravity = who.equals("You") ? Gravity.RIGHT : Gravity.LEFT;
        messages.addView(bubble, p);
    }

    private void sendMessage() {
        String prompt = input.getText().toString().trim();
        if (prompt.isEmpty()) return;
        input.setText("");
        ((InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE))
            .hideSoftInputFromWindow(input.getWindowToken(), 0);
        addMessage("You", prompt);
        status.setText("THINKING...");
        String fullPrompt = prompt;
        if (mode.equals("code")) fullPrompt = "Act as a programming tutor. Generate clear, safe code with explanations. User: " + prompt;
        if (mode.equals("security")) fullPrompt = "Act as an ethical cybersecurity tutor. Only explain legal, authorized lab learning, defensive security, and safe practice. Do not provide instructions to break into real accounts, devices, or networks. User: " + prompt;
        final String requestPrompt = fullPrompt;
        executor.execute(() -> {
            try {
                URL url = new URL(API_URL);
                HttpURLConnection c = (HttpURLConnection)url.openConnection();
                c.setRequestMethod("POST");
                c.setConnectTimeout(20000); c.setReadTimeout(60000);
                c.setDoOutput(true);
                c.setRequestProperty("Content-Type", "application/json; charset=utf-8");
                JSONObject body = new JSONObject();
                body.put("message", requestPrompt);
                try (OutputStream os = c.getOutputStream()) {
                    os.write(body.toString().getBytes(StandardCharsets.UTF_8));
                }
                int code = c.getResponseCode();
                InputStream is = (code >= 200 && code < 300) ? c.getInputStream() : c.getErrorStream();
                ByteArrayOutputStream out = new ByteArrayOutputStream();
                byte[] buf = new byte[4096]; int n;
                while ((n = is.read(buf)) > 0) out.write(buf, 0, n);
                JSONObject response = new JSONObject(out.toString("UTF-8"));
                String answer = response.optString("reply", "No reply returned.");
                runOnUiThread(() -> {
                    addMessage("DarkGPT", answer);
                    status.setText("PRO • READY");
                    // Speak the answer. Android TTS uses the device's installed voices.
                    if (tts != null) tts.speak(answer, TextToSpeech.QUEUE_FLUSH, null, "darkgpt");
                });
                c.disconnect();
            } catch (Exception e) {
                runOnUiThread(() -> {
                    status.setText("CONNECTION ERROR");
                    addMessage("DarkGPT", "সার্ভারের সাথে সংযোগ হয়নি। Backend চালু আছে কি না এবং API_URL ঠিক আছে কি না দেখুন। Details: " + e.getMessage());
                });
            }
        });
    }

    private void startVoice() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            addMessage("DarkGPT", "এই ডিভাইসে Speech Recognition পাওয়া যায়নি।"); return;
        }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, 44); return;
        }
        if (speech != null) speech.destroy();
        speech = SpeechRecognizer.createSpeechRecognizer(this);
        speech.setRecognitionListener(new RecognitionListener() {
            public void onReadyForSpeech(Bundle p) { status.setText("LISTENING..."); }
            public void onBeginningOfSpeech() {}
            public void onRmsChanged(float r) {}
            public void onBufferReceived(byte[] b) {}
            public void onEndOfSpeech() {}
            public void onError(int e) { status.setText("PRO • READY"); }
            public void onResults(Bundle b) {
                ArrayList<String> r = b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                if (r != null && !r.isEmpty()) { input.setText(r.get(0)); sendMessage(); }
                status.setText("PRO • READY");
            }
            public void onPartialResults(Bundle b) {}
            public void onEvent(int e, Bundle p) {}
        });
        Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "bn-BD");
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "bn-BD");
        i.putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak in Bangla or English");
        speech.startListening(i);
    }

    @Override protected void onDestroy() {
        super.onDestroy();
        if (speech != null) speech.destroy();
        if (tts != null) tts.shutdown();
        executor.shutdown();
    }
}
